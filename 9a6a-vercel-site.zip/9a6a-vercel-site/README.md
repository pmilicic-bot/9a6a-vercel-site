# 9A6A – Next.js site for Vercel

This is a first deployable version of the 9A6A website. It uses Next.js App Router and responsive CSS.

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Deploy to Vercel

1. Create a GitHub account/repository (or use an existing one).
2. Upload the contents of this folder to a new repository named `9a6a-vercel-site`.
3. Sign in to https://vercel.com with GitHub.
4. Select **Add New → Project**, import the repository.
5. Framework: Next.js; Build command `next build`; Output settings can remain default.
6. Deploy. In Vercel Project → Settings → Domains, use `9a6a.vercel.app` if available.

The project is prepared but is not published yet; deployment requires the owner's Vercel/GitHub authorization.

## Content migration notes

- The initial content list is based on pages publicly indexed/accessible from https://9a6a.wordpress.com/.
- Some cards currently link to the original WordPress archive because the complete original article text was not available in the public page extracts.
- The America/W3LPL article has an editorial summary page. It is not a verbatim reproduction.
- Images are intentionally placeholders. Add your own images in `public/images/` and then update the components.
- Before public launch, review the About text and contact details; no old personal phone number or private email is included.

## Next migration phase

1. Add original image files to `public/images/`.
2. Expand the article archive from the WordPress category/archive pages.
3. Add article-specific pages and redirects where old slugs can be identified.
4. Review copyright and attribution for third-party images.
