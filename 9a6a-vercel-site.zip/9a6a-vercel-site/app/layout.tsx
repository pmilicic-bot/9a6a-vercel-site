import type { Metadata } from 'next';
import './globals.css';
import Header from '../components/Header';
import Footer from '../components/Footer';
export const metadata: Metadata = {
  title: '9A6A | Amateur Radio, DX & Contesting',
  description: 'Osobna web-stranica Petra Miličića, 9A6A — radioamaterizam, DX, contesting, tehnika i putovanja.',
  metadataBase: new URL('https://9a6a.vercel.app'),
};
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="hr"><body><Header/><main>{children}</main><Footer/></body></html>; }
